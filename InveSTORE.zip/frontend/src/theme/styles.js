const styles = {
  global: {
    'html, body': {
      backgroundColor: '#E2E8F0',
    },
  },
};

export default styles;
